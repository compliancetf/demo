# Compliance evidence pack

**Unsigned. Not independently attested.** This pack records what ctfkit by compliance.tf read from the module manifests installed by `terraform init`. compliance.tf does not sign, attest or verify it.

| | |
|---|---|
| Release | infra |
| Commit | Not set |
| Generated | 2026-11-12T19:35:00Z by ctfkit 0.8.0 |
| Control catalog | 2026.1109.0, the catalog file at `~/.ctf/control-requirements.yaml`, which `ctfkit catalog pull` writes |
| Frameworks | ISO/IEC 27001:2022 |

## 1 Summary

Counts are taken from the module manifests and the control catalog named above.

| | |
|---|---|
| Modules in scope | 11, 9 with a compliance.tf manifest |
| Controls enforced | 15 |
| Controls delegated to another scope | 5 |
| With a ISO/IEC 27001:2022 clause | 12 of 15 |
| Framework gaps with a recorded reason | 0 of 3 |
| Catalog controls for these resource types not enforced here | 88 |
| Control enforcement tests | No tests supplied |
| Findings at error level | 3 |

## 2 Scope

The modules `terraform init` installed for this release. A module without a compliance.tf manifest is listed in the report findings.

| Module | Source | Version | Manifest sha256 |
|---|---|---|---|
| `alb` | `https://iso27001.compliance.tf/terraform-aws-modules/alb/aws?version=10.5.1&disable=elb_application_classic_network_lb_prohibit_public_access` | 10.5.1-0d2c20eb4e5402eb | `974971590b4519572d5d7ba6a86dcfa44dd3aa37b347df8ef5b2c0c58e5c01ec` |
| `ecs` | `iso27001.compliance.tf/terraform-aws-modules/ecs/aws` | 7.6.1-fb919e707797deab | `ce5c627b5f57d31220161fa89382444676dd2c93e6beb0157a47197bf6cd165f` |
| `ecs.cluster` | `./modules/cluster` | 7.6.1-fb919e707797deab | `7a8e8cbfc26d028b777f904271e1679e11571f7197df18700b81425fcefd83bb` |
| `ecs.service` | `./modules/service` | 7.6.1-fb919e707797deab | `e26dbd522de5af464e4d87684eeb37f5815e5d710d05a7911424f1424f7ebac7` |
| `ecs.service.container_definition` | `../container-definition` | 7.6.1-fb919e707797deab | `877633fa2fcf622642d4f0b4d1a5a4364e7bb3dae9f54ea4f6c562f2af30a533` |
| `kms` | `iso27001.compliance.tf/terraform-aws-modules/kms/aws` | 4.2.2-fb919e707797deab | `8ee2d83eaf514bfe795cb3bc3197364bf3f478d23ebe5928635fc6d4eaa04ae7` |
| `ops` | `iso27001.compliance.tf/terraform-aws-modules/ec2-instance/aws` | 6.4.1-fb919e707797deab | `64ca8d28526d6f533acfbbf3675872b8f8c57ff581a9860b1eb643d742ad14d9` |
| `sns` | `iso27001.compliance.tf/terraform-aws-modules/sns/aws` | 7.2.0-fb919e707797deab | `884a8a37a88b884bb14dc5e40a38bb51bd949d063f52ce8870af2144cb92500c` |
| `vpc` | `registry.terraform.io/terraform-aws-modules/vpc/aws` | Not set | None |
| `zone` | `iso27001.compliance.tf/terraform-aws-modules/route53/aws` | 6.5.1-fb919e707797deab | `e583f0041cce3d054350a041f69ea84b6a647b7c1f013ac75f6d8c6409a684d5` |
| `zone.route53_dnssec_kms` | `registry.terraform.io/terraform-aws-modules/kms/aws` | Not set | None |

## 3 What this pack shows, and what it does not

It shows:

- Which compliance controls each installed compliance.tf module enforced when it was built, as the module manifest records them.
- The framework clauses each control is mapped to, with supporting clauses marked as partial or indirect evidence.
- Catalog controls for the same resource types that these modules do not enforce, and the layer that owns each one.
- The results of the enforcement tests supplied with this release, when tests were supplied.

It does not show:

- The state of resources running in AWS. Check that with AWS Config or Audit Manager.
- Organizational or process controls.
- Operation after deployment.
- Computer system validation: no CSV, IQ, OQ or PQ activities, e-signature logic or audit-trail business logic.

## 4 Control-to-clause mapping

Every control each module manifest lists, with the clauses it gives evidence for. A clause marked (supporting) is partial or indirect evidence. None means no clause in that framework; section 5 gives the reason. Clause titles are in annex A.

### Module `alb`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `elb_application_classic_lb_logging_enabled` ELB application and classic load balancer logging should be enabled | enforced | A.8.15 |
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | enforced | None (see 5) |

### Module `ecs`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `cloudwatch_log_group_retention_period_365` CloudWatch log groups should have retention period of at least 365 days | enforced | A.8.15, A.8.16 |
| `ecs_service_not_publicly_accessible` ECS services should not have public IP addresses assigned automatically | delegated | A.8.3 |
| `log_group_encryption_at_rest_enabled` Log groups should have encryption at rest enabled | delegated | A.8.15, A.8.16, A.8.24 |
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | delegated | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | delegated | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | delegated | None (see 5) |

### Module `ecs.cluster`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `cloudwatch_log_group_retention_period_365` CloudWatch log groups should have retention period of at least 365 days | enforced | A.8.15, A.8.16 |
| `log_group_encryption_at_rest_enabled` Log groups should have encryption at rest enabled | enforced | A.8.15, A.8.16, A.8.24 |
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | enforced | None (see 5) |

### Module `ecs.service`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `ecs_service_not_publicly_accessible` ECS services should not have public IP addresses assigned automatically | enforced | A.8.3 |
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | enforced | None (see 5) |

### Module `ecs.service.container_definition`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `cloudwatch_log_group_retention_period_365` CloudWatch log groups should have retention period of at least 365 days | enforced | A.8.15, A.8.16 |
| `log_group_encryption_at_rest_enabled` Log groups should have encryption at rest enabled | enforced | A.8.15, A.8.16, A.8.24 |

### Module `kms`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `kms_cmk_rotation_enabled` KMS CMK rotation should be enabled | enforced | A.8.5, A.8.24 |

### Module `ops`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `ebs_attached_volume_encryption_enabled` Attached EBS volumes should have encryption enabled | enforced | A.8.24 |
| `ec2_instance_iam_profile_attached` EC2 instances should have IAM profile attached | enforced | A.8.2, A.8.20, A.8.21, A.8.22 |
| `ec2_instance_not_publicly_accessible` EC2 instances should not have a public IP address | enforced | A.8.3, A.8.20, A.8.21, A.8.22 |
| `ec2_instance_not_use_multiple_enis` EC2 instances should not use multiple ENIs | enforced | A.8.20, A.8.21, A.8.22 |
| `ec2_instance_uses_imdsv2` EC2 instances should use IMDSv2 | enforced | A.8.20, A.8.21, A.8.22 |
| `ec2_instance_virtualization_type_no_paravirtual` EC2 instances should not use paravirtual instance types | enforced | A.8.20, A.8.21, A.8.22 |
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | enforced | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | enforced | None (see 5) |

### Module `sns`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `sns_topic_encrypted_at_rest` SNS topics should be encrypted at rest | enforced | A.8.24 |

### Module `zone`

| Control | Status | ISO/IEC 27001:2022 |
|---|---|---|
| `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888 | delegated | None (see 5) |
| `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4) | delegated | None (see 5) |
| `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports | delegated | None (see 5) |

## 5 Controls with no clause in a framework

A control can have no matching clause in a framework. The reason comes from the control catalog.

- `vpc_security_group_allows_ingress_to_cassandra_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to cassandra ports 7199 or 9160 or 8888
  - ISO/IEC 27001:2022: Not set
- `vpc_security_group_remote_administration_ipv4` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports (IPv4)
  - ISO/IEC 27001:2022: Not set
- `vpc_security_group_remote_administration_ipv6` VPC security groups should not allow ingress from ::/0 to remote server administration ports
  - ISO/IEC 27001:2022: Not set

## 6 Catalog controls not enforced by these modules

Controls the catalog lists for the resource types of these modules that no module manifest lists, and the layer that owns each one.

| Control | Resource types | Layer | Reason |
|---|---|---|---|
| `autoscaling_ec2_launch_configuration_no_sensitive_data` Auto Scaling launch configurations should not have sensitive data in user data | `aws_instance` | Not set | Not set |
| `autoscaling_launch_config_public_ip_disabled` Auto Scaling launch config public IP should be disabled | `aws_autoscaling_group`, `aws_instance`, `aws_launch_configuration` | Not set | Not set |
| `autoscaling_launch_config_requires_imdsv2` Auto Scaling groups should configure EC2 instances to require IMDSv2 | `aws_autoscaling_group`, `aws_instance` | Not set | Not set |
| `bedrock_model_invocation_logs_encryption_enabled` Bedrock model invocation logs should be encrypted in S3 and CloudWatch Logs | `aws_bedrock_model_invocation_logging_configuration`, `aws_cloudwatch_log_group`, `aws_s3_bucket_server_side_encryption_configuration` | Not set | Not set |
| `directoryservice_directory_log_forwarding_enabled` Directory Service directories should have log forwarding to CloudWatch Logs enabled | `aws_cloudwatch_log_group`, `aws_directory_service_log_subscription` | Not set | Not set |
| `ebs_attached_volume_delete_on_termination_enabled` Attached EBS volumes should have delete on termination enabled | `aws_instance`, `aws_launch_template` | Not set | Not set |
| `ebs_encryption_by_default_enabled` EBS encryption by default should be enabled | `aws_ebs_encryption_by_default`, `aws_instance` | Not set | Not set |
| `ebs_snapshot_not_publicly_restorable` EBS snapshots should not be publicly restorable | `aws_instance` | Not set | Not set |
| `ebs_volume_encryption_at_rest_enabled` EBS volumes should have encryption at rest enabled | `aws_ebs_volume` | Not set | Not set |
| `ebs_volume_in_backup_plan` EBS volumes should be in a backup plan | `aws_backup_plan`, `aws_backup_selection`, `aws_ebs_volume` | Not set | Not set |
| `ebs_volume_snapshot_exists` EBS volumes should have snapshots | `aws_instance` | Not set | Not set |
| `ebs_volume_unused` EBS volumes should be attached to EC2 instances | `aws_ebs_volume`, `aws_volume_attachment` | Not set | Not set |
| `ec2_ami_restrict_public_access` EC2 AMIs should restrict public access | `aws_instance` | Not set | Not set |
| `ec2_elastic_ip_shodan` EC2 Elastic IP addresses should not be listed in Shodan | `aws_instance` | Not set | Not set |
| `ec2_instance_attached_ebs_volume_delete_on_termination_enabled` EC2 instances should have attached EBS volumes marked for deletion on termination | `aws_instance` | Not set | Not set |
| `ec2_instance_detailed_monitoring_enabled` EC2 instances should have detailed monitoring enabled | `aws_instance` | Not set | Not set |
| `ec2_instance_ebs_optimized` EC2 instances should have EBS optimization enabled | `aws_instance` | Not set | Not set |
| `ec2_instance_in_vpc` EC2 instances should be in a VPC | `aws_instance` | Not set | Not set |
| `ec2_instance_no_amazon_key_pair` EC2 instances should not use key pairs in running state | `aws_instance` | Not set | Not set |
| `ec2_instance_no_launch_wizard_security_group` EC2 instances should not be attached to 'launch wizard' security groups | `aws_instance` | Not set | Not set |
| `ec2_instance_port_rdp_exposed_to_internet` EC2 instances should not allow ingress from the Internet to TCP port 3389 (RDP) | `aws_instance` | Not set | Not set |
| `ec2_instance_protected_by_backup_plan` EC2 instances should be protected by backup plan | `aws_instance` | Not set | Not set |
| `ec2_instance_publicly_accessible_iam_profile_attached` Public EC2 instances should have IAM profile attached | `aws_instance` | Not set | Not set |
| `ec2_instance_ssm_managed` EC2 instances should be managed by AWS Systems Manager | `aws_instance` | Not set | Not set |
| `ec2_instance_termination_protection_enabled` EC2 instances should have termination protection enabled | `aws_instance` | Not set | Not set |
| `ec2_instance_user_data_no_secrets` EC2 instances user data should not have secrets | `aws_instance` | Not set | Not set |
| `ec2_instance_using_iam_instance_role` EC2 instances should use IAM instance roles for AWS resource access | `aws_instance` | Not set | Not set |
| `ec2_securitygroup_allow_wide_open_public_ipv4` Security groups should not have ingress or egress rules with public IPv4 CIDR ranges from /1 to /23 | `aws_instance` | Not set | Not set |
| `ec2_securitygroup_with_many_ingress_egress_rules` Security groups should have 50 or fewer inbound rules and 50 or fewer outbound rules | `aws_instance` | Not set | Not set |
| `ec2_stopped_instance_30_days` EC2 stopped instances should be removed in 30 days | `aws_instance` | Not set | Not set |
| `ec2_stopped_instance_90_days` EC2 instances stopped for over 90 days should be removed | `aws_instance` | Not set | Not set |
| `ecs_cluster_instance_in_vpc` ECS cluster instances should be in a VPC | `aws_instance`, `aws_launch_template` | Not set | Not set |
| `ecs_service_fargate_using_latest_platform_version` ECS fargate services should run on the latest fargate platform version | `aws_ecs_service` | Not set | Not set |
| `ecs_service_load_balancer_attached` ECS services should be attached to a load balancer | `aws_ecs_service` | Not set | Not set |
| `elb_application_classic_network_lb_prohibit_public_access` ELB load balancers should prohibit public access | `aws_lb` | Not set | Not set |
| `elb_application_gateway_network_lb_multiple_az_configured` ELB application, network, and gateway load balancers should span multiple availability zones | `aws_lb` | Not set | Not set |
| `elb_application_lb_deletion_protection_enabled` ELB application load balancer deletion protection should be enabled | `aws_lb` | Not set | Not set |
| `elb_application_lb_desync_mitigation_mode` ELB application load balancers should be configured with defensive or strictest desync mitigation mode | `aws_lb` | Not set | Not set |
| `elb_application_lb_drop_http_headers` ELB application load balancers should be configured to drop HTTP headers | `aws_lb` | Not set | Not set |
| `elb_application_lb_http_drop_invalid_header_enabled` ELB application load balancers should drop invalid HTTP headers | `aws_lb` | Not set | Not set |
| `elb_application_lb_redirect_http_request_to_https` ELB application load balancers should redirect HTTP requests to HTTPS | `aws_lb` | Not set | Not set |
| `elb_application_lb_waf_enabled` ELB application load balancers should have Web Application Firewall (WAF) enabled | `aws_lb` | Not set | Not set |
| `elb_application_lb_with_outbound_rule` ELB application load balancers should have at least one outbound rule | `aws_lb`, `aws_security_group`, `aws_vpc_security_group_egress_rule` | Not set | Not set |
| `elb_application_network_lb_use_listeners` ELB application and network load balancers should use listeners | `aws_lb` | Not set | Not set |
| `elb_classic_lb_use_ssl_certificate` ELB classic load balancers should use SSL certificates | `aws_lb` | Not set | Not set |
| `elb_classic_lb_use_tls_https_listeners` ELB classic load balancers should only use SSL or HTTPS listeners | `aws_elb`, `aws_lb` | Not set | Not set |
| `elb_classic_lb_with_inbound_rule` ELB classic load balancers should have at least one inbound rule | `aws_elb`, `aws_security_group`, `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `elb_listener_use_secure_ssl_cipher` ELB listeners should use secure SSL cipher | `aws_lb` | Not set | Not set |
| `kafka_cluster_encryption_at_rest_uses_cmk` MSK clusters should have encryption at rest enabled using a customer managed KMS key | `aws_kms_key`, `aws_msk_cluster` | Not set | Not set |
| `kms_cmk_not_multi_region` KMS customer managed keys should not be multi-Region | `aws_kms_key` | Not set | Not set |
| `kms_cmk_policy_prohibit_public_access` KMS CMK policies should prohibit public access | `aws_kms_key` | Not set | Not set |
| `kms_cmk_unused` KMS key should be in use | `aws_kms_key` | Not set | Not set |
| `kms_key_decryption_restricted_in_iam_customer_managed_policy` KMS key decryption should be restricted in IAM customer managed policy | `aws_kms_key` | Not set | Not set |
| `kms_key_decryption_restricted_in_iam_inline_policy` KMS key decryption should be restricted in IAM inline policy | `aws_kms_key` | Not set | Not set |
| `kms_key_not_pending_deletion` KMS keys should not be pending deletion | `aws_kms_key` | Not set | Not set |
| `sagemaker_training_job_volume_and_data_encryption_enabled` SageMaker training jobs volumes and outputs should have KMS encryption enabled | `aws_kms_key`, `aws_sagemaker_training_job` | Not set | Not set |
| `sns_subscription_not_using_http_endpoints` SNS subscriptions should use HTTPS endpoints | `aws_sns_topic` | Not set | Not set |
| `sns_topic_notification_delivery_status_enabled` SNS topics should have delivery status logging enabled for notification messages | `aws_sns_topic` | Not set | Not set |
| `sns_topic_policy_prohibit_public_access` SNS topic policies should prohibit public access | `aws_sns_topic`, `aws_sns_topic_policy` | Not set | Not set |
| `sns_topic_policy_prohibit_publishing_access` SNS topic policies should prohibit publishing access | `aws_sns_topic`, `aws_sns_topic_policy` | Not set | Not set |
| `sns_topic_policy_prohibit_subscription_access` SNS topic policies should prohibit subscription public access | `aws_sns_topic`, `aws_sns_topic_policy` | Not set | Not set |
| `storagegateway_fileshare_encryption_enabled` Storage Gateway file shares should be encrypted using a customer managed KMS key | `aws_kms_key`, `aws_storagegateway_nfs_file_share`, `aws_storagegateway_smb_file_share` | Not set | Not set |
| `vpc_configured_to_use_interface_endpoint_for_docker_registry` VPCs should be configured with an interface endpoint for Docker Registry | `aws_instance` | Not set | Not set |
| `vpc_configured_to_use_interface_endpoint_for_ecr_api` VPCs should be configured with an interface endpoint for ECR API | `aws_instance` | Not set | Not set |
| `vpc_configured_to_use_interface_endpoint_for_ssm` VPCs should be configured with an interface endpoint for Systems Manager | `aws_instance` | Not set | Not set |
| `vpc_configured_to_use_interface_endpoint_for_ssm_contacts` VPCs should be configured with an interface endpoint for Systems Manager Incident Manager Contacts | `aws_instance` | Not set | Not set |
| `vpc_configured_to_use_interface_endpoint_for_ssm_incidents` VPCs should be configured with an interface endpoint for Systems Manager Incident Manager | `aws_instance` | Not set | Not set |
| `vpc_configured_to_use_vpc_endpoints` VPCs should use VPC endpoints | `aws_instance` | Not set | Not set |
| `vpc_default_security_group_restricts_all_traffic` VPC default security group should not allow inbound and outbound traffic | `aws_default_security_group`, `aws_instance`, `aws_vpc` | Not set | Not set |
| `vpc_eip_associated` VPC EIPs should be associated with an EC2 instance or ENI | `aws_eip`, `aws_eip_association`, `aws_instance` | Not set | Not set |
| `vpc_flow_logs_enabled` VPC flow logs should be enabled | `aws_instance`, `aws_vpc` | Not set | Not set |
| `vpc_network_acl_remote_administration` Network ACLs should not allow ingress from 0.0.0.0/0 to port 22 or port 3389 | `aws_instance` | Not set | Not set |
| `vpc_network_acl_unused` VPC network ACLs should be associated with a subnet | `aws_instance` | Not set | Not set |
| `vpc_security_group_allows_ingress_authorized_ports` VPC Security groups should only allow unrestricted incoming traffic for authorized ports | `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `vpc_security_group_allows_ingress_to_memcached_port` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to memcached port 11211 | `aws_instance` | Not set | Not set |
| `vpc_security_group_allows_ingress_to_mongodb_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to mongoDB ports 27017 and 27018 | `aws_instance` | Not set | Not set |
| `vpc_security_group_allows_ingress_to_oracle_ports` VPC security groups should restrict ingress from 0.0.0.0/0 or ::/0 to oracle ports 1521 or 2483 | `aws_instance` | Not set | Not set |
| `vpc_security_group_associated_to_eni` VPC security groups should be associated with at least one ENI | `aws_instance` | Not set | Not set |
| `vpc_security_group_not_uses_launch_wizard_sg` VPC security groups should restrict uses of 'launch-wizard' security groups | `aws_instance` | Not set | Not set |
| `vpc_security_group_remote_administration` VPC security groups should not allow ingress from 0.0.0.0/0 to remote server administration ports | `aws_instance` | Not set | Not set |
| `vpc_security_group_restrict_ingress_cifs_port_all` VPC security groups should restrict ingress CIFS access from 0.0.0.0/0 and ::/0 | `aws_security_group`, `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `vpc_security_group_restrict_ingress_common_ports_all` VPC security groups should restrict ingress access on ports 20, 21, 22, 3306, 3389, 4333 from 0.0.0.0/0 | `aws_instance` | Not set | Not set |
| `vpc_security_group_restrict_ingress_kibana_port` VPC security groups should restrict ingress kibana port access from 0.0.0.0/0 | `aws_instance` | Not set | Not set |
| `vpc_security_group_restrict_ingress_rdp_all` VPC security groups should not allow ingress from 0.0.0.0/0 to port 3389 | `aws_instance`, `aws_security_group`, `aws_security_group_rule`, `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `vpc_security_group_restrict_ingress_redis_port` VPC security groups should restrict ingress redis access from 0.0.0.0/0 | `aws_security_group`, `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `vpc_security_group_restrict_ingress_ssh_all` VPC security groups should restrict ingress SSH access from 0.0.0.0/0 | `aws_instance`, `aws_security_group`, `aws_security_group_rule`, `aws_vpc_security_group_ingress_rule` | Not set | Not set |
| `vpc_security_group_restricted_common_ports` Security groups should not allow unrestricted access to ports with high risk | `aws_instance` | Not set | Not set |
| `vpc_vpn_tunnel_up` VPN tunnels should be in UP status for both tunnels provided by AWS Site-to-Site VPN | `aws_instance` | Not set | Not set |

## 7 Enforcement tests

No tests supplied. Pass `--tests-json` to `ctfkit report` to include the results of `tofu test -json` or `terraform test -json`.

## Annex A Clause register

Every clause cited in this pack, as the module manifests name it, and the clauses the catalog records no control applies to.

### ISO/IEC 27001:2022

| Clause | Title | Controls |
|---|---|---|
| A.8.2 | Privileged access rights | `ec2_instance_iam_profile_attached` |
| A.8.3 | Information access restriction | `ec2_instance_not_publicly_accessible`, `ecs_service_not_publicly_accessible` |
| A.8.5 | Secure authentication | `kms_cmk_rotation_enabled` |
| A.8.15 | Logging | `cloudwatch_log_group_retention_period_365`, `elb_application_classic_lb_logging_enabled`, `log_group_encryption_at_rest_enabled` |
| A.8.16 | Monitoring activities | `cloudwatch_log_group_retention_period_365`, `log_group_encryption_at_rest_enabled` |
| A.8.20 | Network security | `ec2_instance_iam_profile_attached`, `ec2_instance_not_publicly_accessible`, `ec2_instance_not_use_multiple_enis`, `ec2_instance_uses_imdsv2`, `ec2_instance_virtualization_type_no_paravirtual` |
| A.8.21 | Security of network services | `ec2_instance_iam_profile_attached`, `ec2_instance_not_publicly_accessible`, `ec2_instance_not_use_multiple_enis`, `ec2_instance_uses_imdsv2`, `ec2_instance_virtualization_type_no_paravirtual` |
| A.8.22 | Segregation of networks | `ec2_instance_iam_profile_attached`, `ec2_instance_not_publicly_accessible`, `ec2_instance_not_use_multiple_enis`, `ec2_instance_uses_imdsv2`, `ec2_instance_virtualization_type_no_paravirtual` |
| A.8.24 | Use of cryptography | `ebs_attached_volume_encryption_enabled`, `kms_cmk_rotation_enabled`, `log_group_encryption_at_rest_enabled`, `sns_topic_encrypted_at_rest` |

Clauses with no applicable control: None.

---

Unsigned. Not independently attested.
